public class Build_Shake {
    Shake shake;
    public void setShake(Shake shake) {
        this.shake = shake;
    }

    public void Make_lactose_free()
    {
        shake.make_Lactose_Free();
    }
    public void add_candy()
    {
        shake.add_candy();
    }
    public void add_cookies()
    {
        shake.add_cookies();
    }
}
