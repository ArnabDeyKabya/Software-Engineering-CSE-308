public interface Passanger {
    public void repair();
    public void work();
    public void logout();
    public void login();
}
